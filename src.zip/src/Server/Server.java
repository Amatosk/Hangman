package Server;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Server {
	
	static ServerSocket server;
	
	//Array list containing all the possible words that could be chosen for the game
	static List<String> listOfWords = new ArrayList<String>();
	
	
	private static String wordToFind;//Move this somewhere else so that a different word
									 //is generated on each new connection

	
	public static void main(String[] args) {
		
		try {
			//Initiates the ServerSocket with the port number 4500
			server = new ServerSocket(4500);
			
			//A String is made and the absolute file path to the current directory is retreived
			String filePath = new File("").getAbsolutePath();

			//Combined with the earlier absolute file path, we go through some more directories
			//to reach the txt file.
			File txtFile = new File(filePath + "/src/Resources/words.txt");
			
			//Buffered Reader combined with a File Reader to read entire lines from the words.txt 
			//file in the Resources folder.
			BufferedReader buffRead = new BufferedReader(new FileReader(txtFile));
			
			//String that gets the first line from the Buffered Reader
			String line = buffRead.readLine();
			
			//While the String is not null (Which will happen when we reach the end of the file)
			while(line != null){
				
				//We add the current value of the String to the array list...
				listOfWords.add(line);
				
				//and read the next line from the file. 
				line = buffRead.readLine();
				
				//The loop will then check again whether the new value of the String is null or not
			}
			
			//We close the Buffered Reader to prevent a resource leak.
			buffRead.close();
			
			//We create a socket so that we can prepare for clients connecting to this server
			//Socket client;
			
			//An infinite loop means that the server can wait indefinitely for something to happen
			while(true) {
				
				//When a client connects, that client is saved to the socket that was just created
				Socket client = server.accept();
				
				//We print to the console what the IP address of that client is
				System.out.println("Connected to client at " + client.getInetAddress());
				
				//and make a thread for that client and start that thread, so that can handle
				//communication with the individual client instead of this class. The loop can
				//then start anew and wait for the next client.
				if(client.isConnected()) {
					ClientThread thread = new ClientThread(client);
					thread.start();
				}
				
				
			}
			
			
			//Math.random generates a random number between 0.0 and 1.0, so if we multiply it by the
			//size of the arraylist and convert it into an int, we can get a whole number that is 
			//between 0 and the full length of the arraylist. We use that number to retreive one word
			//from the list and save that word to the String, wordToFind.
			
			//wordToFind = listOfWords.get((int)(Math.random()*listOfWords.size()));
			
			//For debugging purposes, the word is printed to the console.
			
			//System.out.println("The word to find is -" + wordToFind + "-");
			
			
			
			
		}catch(IOException ioe) {
			ioe.printStackTrace();
		}
		
		
		
	}
	
	

}
