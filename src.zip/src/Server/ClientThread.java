package Server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Arrays;

public class ClientThread extends Thread{
	
	Socket client;
	String wordToFind;
	PrintWriter out;
	BufferedReader in;
	String difficultyLevel;
	char[] currentWordState;
	
	public ClientThread(Socket s) {
		client = s;
	}
	
	public void run() {
		
		try {
			out = new PrintWriter(client.getOutputStream(),true);
			in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			
			while(true) {
				String[] messageCheck = in.readLine().split(" ");
				switch(messageCheck[0]) {
				case "StartUpGame" : 
					//Ternary operator, asking whether the second element of the messageCheck array
					//is equal to 7. If so, difficultyLevel is set to Easy. Otherwise, we use another
					//ternary operator to ask whether the second element of messageCheck is equal to
					//5. If so, difficultyLevel is set to Medium. Otherwise, it is set to Hard.
					
					difficultyLevel = (messageCheck[1].equals("7")) ? "Easy" : (messageCheck[1].equals("5")) ? "Medium" : "Hard";
					
					//Math.random generates a random number between 0.0 and 1.0. By multiplying it by
					//the size of the ArrayList over in the Server class and converting the result to
					//an int, we get a whole number between 0 and the size of the list. That number is
					//used to get one specific element from that ArrayList and saves that word to the
					//string variable here, called wordToFind. 
					wordToFind = Server.listOfWords.get((int)(Math.random()*(Server.listOfWords.size())));
					currentWordState = new char[wordToFind.length()];
					Arrays.fill(currentWordState,'_');

					System.out.println("User " + client.getLocalSocketAddress() + " is playing on " + difficultyLevel + " mode and is looking for the word \"" + wordToFind + "\" ");
					out.println("true");
					
					break;
				case "GetWord" :
					//Return the word that the player should be looking for
					out.println(new String(currentWordState));
					
					break;
					
				case "LetterGuess" :
					char theGuess = messageCheck[1].charAt(0);
					boolean success = false;
					//Get the letter and check the word. Server side so hacking is harder. 
					for(int i = 0; i < wordToFind.length() ; i++) {
						if(wordToFind.charAt(i)== Character.toLowerCase(theGuess)) {
							currentWordState[i] = Character.toLowerCase(theGuess);
							success = true;
						}
					}
					
					String returnValue = new String(currentWordState);
					boolean finished = (wordToFind.equals(returnValue));

					out.println(returnValue + " " + success + " " + finished);
					break;
				
				
				
				
				}
				
				
				
			}
			
			
			
		}catch(IOException ioe) {
			ioe.printStackTrace();
		}catch(NullPointerException npe) {
			try {
				client.close();
			}catch(IOException ioe) {
				//Nothing, because we just want to close the connection.
			}
		}
		
		
		
	}
	

}
