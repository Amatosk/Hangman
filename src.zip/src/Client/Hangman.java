package Client;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ConnectException;
import java.net.Socket;
import java.util.Optional;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

public class Hangman extends Application{
	
	//A ServerSocket and client Socket are prepared, but cannot be initialised outside of a 
	//try block because of the IOException they could potentially throw. 
	//While it seems pointless to have both a server and client socket in the same class, it
	//is merely to show how communications could be performed using a connection. 
	static Socket client;
	
	//A PrintWriter and BufferedReader are prepared here, but can also throw IOExceptions, so
	//they are also initialised inside the try block. Both of these will be used by the client
	//Socket so that it can handle communications with the Server Socket that it is connected to
	static PrintWriter out;
	static BufferedReader in;
	
	
	//Needed in class scope because an anonymous inner class changes these values. However, these
	//values are also used elsewhere, so these variables cannot stay within the inner class' scope.
	String statusMessage;
	Label statusMessageLabel = new Label();
	
	Scene scene;
	Group group;
	int difficultyGuesses = 0;//Easy, medium, hard/The amount of guesses corresponding to difficulty
	boolean finished;//Finished the word?
	char[] currentGuesses;//Letters that have been guessed so far
	Label currentGuessesLabel;//A label for currentGuesses to appear on screen
	Label currentWordLabel;
	Label attemptsRemainingLabel;
	HBox finalLine;
	VBox massiveSpacing;
	Region eh = new Region();
	int remainingGuesses;//If difficultyGuesses is the amount of guesses the player will have thanks to difficulty,
						//remainingGuesses is the amount of guesses left, counting down if the player makes mistakes
	double drawnPieces = 0.0;//Amount of hangman pieces to draw on screen
		
	public static void main(String[] args){
		
		try{
			//Socket attempts to connect to the same computer, localhost, using the port number 4500
			client = new Socket("localhost", 4500);
			
			//A PrintWriter is connected to the OutputStream of the client Socket. 
			//The boolean determines whether it should auto-flush or not.
			out = new PrintWriter(client.getOutputStream(),true);
			
			//The BufferedReader creates a Buffer for the InputStreamReader, which in turn
			//reads from the InputStream of the client Socket. 
			in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			

		//FileNotFoundException may be thrown if a file could not be found by the FileReader
		}catch(FileNotFoundException fnfe){
			fnfe.printStackTrace();
			
		//IOException may be thrown if the Buffered Reader could not read a line from the file it 
		//was supposed to be connected to, or if either the Socket or the ServerSocket cannot use 
		//the port number given. PrintWriter and BufferedReader may also throw this exception
		//because of their dependence on the socket
		}catch(ConnectException ce) {
			System.out.println("Could not connect to the server. Please ensure that the server is active before starting the game.");
			System.exit(1);
		}catch(IOException ioe){
			ioe.printStackTrace();
		}
		
		

		

		
		//The user should be allowed 3 incorrect guesses, but between a combination of that 
		//and making correct guesses, they should not be able to make any more guesses than 
		//the length of the word that they're looking for plus the incorrect 3

		
		
		//The array will later be used to display to the user which letters they've used
		//currentGuesses = new char[wordToFind.length() + remainingGuesses];
		
		launch(args);
		
	}
	
	
	public void start(Stage stage) {
		
		//First screen needs difficulty setting stuff
		
		Label chooseADifficulty = new Label("Please choose your difficulty preference");
		ComboBox<String> difficultyChoices = new ComboBox<String>();
		difficultyChoices.getItems().add("Easy");
		difficultyChoices.getItems().add("Medium");
		difficultyChoices.getItems().add("Hard");
		difficultyChoices.getSelectionModel().selectFirst();
		Button difficultyConfirm = new Button("Confirm");
		VBox difficultyHBox = new VBox(20,chooseADifficulty, difficultyChoices, difficultyConfirm);
		difficultyHBox.setAlignment(Pos.CENTER);
		
		group = new Group(difficultyHBox);
		
		scene = new Scene(group, 300,300, Color.LIGHTGREY);
		stage.setScene(scene);
		stage.setResizable(false);
		stage.setTitle("Hangman");
		stage.show();
		
		
		difficultyConfirm.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>(){
			@Override
			public void handle(MouseEvent e){
				Alert confirmation = new Alert(AlertType.CONFIRMATION);
				confirmation.setTitle("Start game?");
				
				confirmation.setHeaderText("Do you wish to start the game on " + difficultyChoices.getValue() + " difficulty?");

				Optional<ButtonType> result = confirmation.showAndWait();
				
				if(result.get() == ButtonType.OK) {
					//Set the amount of guesses variable to a value based on the difficulty chosen
					//and send that number over to the server so that it can pick a word to send
					//back. Using the number helps to get around hackers because if they change the
					//value beforehand, so that they can get more chances, the server won't be able 
					//to respond in the normal way. The server can just disconnect from this client 
					//instead when it happens
					finished = false;
					switch(difficultyChoices.getValue()) {
					case "Easy"   : difficultyGuesses = 7;
									System.out.println("Picked Easy mode");
									break;
					case "Medium" : difficultyGuesses = 5;
									System.out.println("Picked Medium mode");
									break;
					case "Hard"   : difficultyGuesses = 3;
									System.out.println("Picked Hard mode");
									break;
					default 	  : System.out.println("For some reason, we didn't get a difficulty setting");
									System.exit(1);
									break;//Yeah, we should probably just close the game here.
					}
										
					out.println("StartUpGame " + difficultyGuesses);
					boolean connectionCheck = false;//I mean, a boolean would be nice
					while(!connectionCheck) {						
						try {
							//out.println("StartUpGame " + difficultyGuesses);

							connectionCheck = Boolean.parseBoolean(in.readLine());
							//String whyIsThisHappening = in.readLine();
							System.out.println(connectionCheck);
						}catch(IOException ioe) {
							//Do nothing. wordToFind remains null and the loop keeps going until
							//something has been retreived.
						}
					}
					
					//Ok, we got a connection and the server (ClientThread) has made a word.
					//We can set this variable back to null, since we're past the ghetto waiting
					//section and can proceed with the game. The client shouldn't keep the word
					//because hackers could access the word and get a perfect score from it. 
					
					//connectionCheck = false;
					
					confirmation.close();
					
					//Call the game method, passing over the stage and scene so that it can be 
					//redesigned and the difficultyGuesses int so that we can use it 
					game(stage);
					
				}
			}
		});

		
		
		
		
		
		
		
		
		

		//We need the amount of attempts remaining. This can probably be on the same line as above
		
		//Well, I mean, we'd need to be able to actually get input from the user too
		//Scene event listener so the user doesn't even need to click in a textfield or anything?
		//If so, we should have that simple instruction on the screen
		
	}
	
	private void game(Stage stage) {
		
		group.getChildren().clear();
		
		Label instructions = new Label("Please type a letter you would like to try");
		instructions.setAlignment(Pos.TOP_CENTER);
		char[] wordInProgress = new char[wordToFind().length()];
		Label wordInProgressLabel = new Label();		
		
		//Noose and things
		Line ground = new Line(200,230,250,230);
		Line upright = new Line(250,230,250,30);
		Line cross = new Line(150,30,250,30);
		Group noose = new Group(ground,upright,cross);
		

		

		//List of characters that the user has tried, whether successful or not
		currentGuesses = new char[wordInProgress.length + difficultyGuesses];
		currentGuessesLabel = new Label();
		
		remainingGuesses = difficultyGuesses;
		attemptsRemainingLabel = new Label("Attempts remaining: " + remainingGuesses);
		attemptsRemainingLabel.setAlignment(Pos.CENTER_LEFT);
		
		group = new Group(instructions, wordInProgressLabel,noose);
		finalLine = new HBox(5,currentGuessesLabel,eh,attemptsRemainingLabel);
		HBox.setHgrow(eh,Priority.ALWAYS);
		finalLine.setAlignment(Pos.BOTTOM_LEFT);
		massiveSpacing = new VBox(5,group,statusMessageLabel,currentWordLabel,finalLine);
		massiveSpacing.setAlignment(Pos.CENTER);
		Group newGroup = new Group(massiveSpacing,hangTheMan(Math.toIntExact(Math.round(drawnPieces))));

		scene = new Scene(newGroup,300,300,Color.LIGHTGREY);
		stage.setScene(scene);
		stage.setResizable(false);
		stage.setTitle("Hangman");

		keyRel(stage);
		stage.show();
	}
	
	
	private Group hangTheMan(int wrong) {
		
		//Rope - Line
		Line rope = new Line(150,30,150,55);
		//Head - Circle
		Circle head = new Circle(150,75,20);
		head.setFill(Color.BLUE);
		//Body - Line
		Line body = new Line(150,95,150,150);
		//Left arm - Line
		Line leftArm = new Line(150,105,120,115);
		//Right arm - Line
		Line rightArm = new Line(150,105,180,115);
		//left leg - Line
		Line leftLeg = new Line(150,150,130,180);
		//Right leg - Line
		Line rightLeg = new Line(150,150,170,180);
		
		Group[] hangedMan = {new Group(rope),new Group(head),new Group(body),new Group(leftArm),
							new Group(rightArm),new Group(leftLeg),new Group(rightLeg)};
		
		Group toReturn = new Group();
		
		for(int i = 0; i < wrong; i++) {
			toReturn.getChildren().add(hangedMan[i]);
		}
		return toReturn;
	}
	
	
	
	//keyRel - keyReleased - setOnKeyReleased
	private void keyRel(Stage stage) {
		
		scene.setOnKeyReleased(new EventHandler<KeyEvent>() {
			
			@Override
			public void handle(KeyEvent e) {
				
				if(e.getCode().isLetterKey()) {
					
					char letter = e.getText().charAt(0);
					boolean same = false;
					
					for(int i = 0; i < currentGuesses.length; i++) {
						
						//If the letter that the user input is the same as the letter found
						//in the currentGuesses char array, the same boolean variable is set
						//to true and we break out of the loop.
						if(letter==currentGuesses[i]) {
							same = true;
							break;
							
						//Otherwise, if we reached a point in the array that has a value of
						//0, instead of a letter, we replace that 0 with the letter that the
						//user just input and break out of the loop, because we know everything
						//past this point are also blanks.
						}else if(currentGuesses[i]==0) {
							currentGuesses[i] = letter;
							break;
						}
					}
					
					//If the letter isn't the same as one already guessed, we go here
					if(!same) {
						out.println("LetterGuess " + letter);
						String currentWord = null;
						String[] receive = new String[3];
					
						while(currentWord == null) {
						
							//Keep looping until we get something
							try {
								receive = in.readLine().split(" ");
								currentWord = receive[0];
							}catch(IOException ioe) {
								
							}
						}
						boolean success = Boolean.parseBoolean(receive[1]);
						finished = Boolean.parseBoolean(receive[2]);
						if(success) {
							statusMessageLabel = new Label("There is a '" + letter + "' in the word!");
						}else {
							statusMessageLabel = new Label("There was no '" + letter + "' in the word.");
							remainingGuesses--;
							drawnPieces += (7.0/difficultyGuesses);
						}
						
						
						

						System.out.println(currentWord);
						
						currentWordLabel = new Label(currentWord);
						
					//If the letter is the same as one already guessed, we go here instead
					}else {
						
						//Inform the user that they already tried their letter
						
						//letter
						statusMessageLabel = new Label("The letter '" + letter + "' has already been used");
						
						
						
					}
					
					if(remainingGuesses==0) {
						//Game over
						gameOver(stage);
						
						
					}
					if(finished) {
						//Congratulations
						gameVictory(stage);
						
					}
					
					
					
					//Here lies the code for updating the UI
					//hopefully
					
					currentGuessesLabel = new Label(new String(currentGuesses));
					attemptsRemainingLabel = new Label("Attempts remaining: " + remainingGuesses);

					finalLine = new HBox(5,currentGuessesLabel,eh,attemptsRemainingLabel);
					HBox.setHgrow(eh,Priority.ALWAYS);

					finalLine.setAlignment(Pos.CENTER_LEFT);
					massiveSpacing = new VBox(5,group,statusMessageLabel,currentWordLabel,finalLine);
					massiveSpacing.setAlignment(Pos.CENTER);
					
					Group newGroup = new Group(massiveSpacing,hangTheMan(Math.toIntExact(Math.round(drawnPieces))));
					scene = new Scene(newGroup,300,300,Color.LIGHTGREY);
					stage.setScene(scene);
					keyRel(stage);
					
				}else if(e.getCode()==KeyCode.ESCAPE) {
					Alert alert = new Alert(AlertType.CONFIRMATION);
					alert.setTitle("Quit game");
					alert.setHeaderText(null);
					alert.setContentText("Are you sure you wish to quit the game?\nYour progress will not be saved.");
					Optional<ButtonType> result = alert.showAndWait();
					
					if(result.get() == ButtonType.OK) {
						try {
							client.close();
						}catch(IOException ioe) {
							//Well, I dunno. We want to close the whole client program if they do this.
						}
						stage.close();
					}	
				}	
			}
		});
	}
	
	private void gameOver(Stage stage) {
		
		//Alright, group.getChildren().clear(); won't work because the scene has more
		//than just that. It'll be better to just recreate scene entirely.
		//scene = new Scene(stuff,300,300,Color.LIGHTGREY);
		
		
		
		
		
	}
	
	private void gameVictory(Stage stage) {
		
		group.getChildren().clear();

		
		
		
	}
	
	
	
	private String wordToFind() {
		
		//It actually just gets the incomplete version of the word, with underscores.
		//By the point this method is called, the server will have created a thread for
		//this client and generated a random word for this client to aim for. 
		//The underscore variant will be just as long as the real word, so it can be used
		//for array lengths and, since it'll be all underscores, even if a hacker went to
		//print out the value of temp, they wouldn't get anywhere.
		out.println("GetWord");
		String temp = null;
		while(true) {
			try {
				temp = in.readLine();
				if(temp!=null) {
					System.out.println(temp);
					currentWordLabel = new Label(temp);
					return temp;
				}
			}catch(IOException ioe) {
				//Oh my
			}
		}
	}
}
